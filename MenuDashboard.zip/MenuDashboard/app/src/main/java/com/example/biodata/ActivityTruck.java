package com.example.biodata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityTruck extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_truck);
    }
}