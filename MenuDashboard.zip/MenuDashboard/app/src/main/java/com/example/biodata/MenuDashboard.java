package com.example.biodata;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuDashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_dashboard);
    }

    public void SepedaClick(View view) {
        Intent Intent = new Intent(MenuDashboard.this,ActivitySepeda.class);
        startActivity(Intent);
    }

    public void PlaneClick(View view) {
        Intent Intent = new Intent(MenuDashboard.this,ActivityPlane.class);
        startActivity(Intent);
    }

    public void TruckClick(View view) {
        Intent Intent = new Intent(MenuDashboard.this,ActivityTruck.class);
        startActivity(Intent);
    }

    public void BusClick(View view) {
        Intent Intent = new Intent(MenuDashboard.this,ActivityBus.class);
        startActivity(Intent);
    }

    public void FoodClick(View view) {
        Intent Intent = new Intent(MenuDashboard.this,ActivityFood.class);
        startActivity(Intent);
    }

    public void SchoolClick(View view) {
        Intent Intent = new Intent(MenuDashboard.this,ActivitySchool.class);
        startActivity(Intent);
    }
}