package com.example.animeshinchan;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class CreateShinchan extends AppCompatActivity {
    protected Cursor cursor;
    Database database;
    Button btn_save;
    TextView nama, cirikhas,jenis,hobbi,lebihkrg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_shinchan);
        database = new Database(this);
        nama = findViewById(R.id.nama);
        cirikhas = findViewById(R.id.cirikhas);
        jenis = findViewById(R.id.JK);
        hobbi = findViewById(R.id.Hobi);
        lebihkrg = findViewById(R.id.lbhkrg);
        btn_save = findViewById(R.id.btnsave);
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = database.getWritableDatabase();
                db.execSQL("insert into shinchan(nama, cirikhas,jenis,hobbi,lebihkrg) values('"+
                        nama.getText().toString()+ "','"
                        + cirikhas.getText().toString() + "','" + jenis.getText().toString()+ "','"+
                        hobbi.getText().toString()+"','"+ lebihkrg.getText().toString()+"')");
                Toast.makeText(CreateShinchan.this, "Data tersimpan", Toast.LENGTH_SHORT).show();
                MainActivity.ma.RefreshList();
                finish();
            }
        });






    }
}