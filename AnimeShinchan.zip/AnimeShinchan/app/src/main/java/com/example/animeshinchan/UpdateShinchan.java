package com.example.animeshinchan;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class UpdateShinchan extends AppCompatActivity {
    protected Cursor cursor;
    Database database;
    Button btn_save;
    TextView nama, cirikhas,jenis,hobbi,lebihkrg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_shinchan);
        database = new Database(this);
        nama = findViewById(R.id.nama);
        cirikhas = findViewById(R.id.cirikhas);
        hobbi = findViewById(R.id.Hobi);
        jenis = findViewById(R.id.JK);
        lebihkrg = findViewById(R.id.lbhkrg);
        btn_save = findViewById(R.id.btnsave);
        SQLiteDatabase db = database.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM shinchan WHERE nama = '" +
                getIntent().getStringExtra("nama") + "'", null);
        cursor.moveToFirst();
        if (cursor.getCount() > 0) {
            cursor.moveToPosition(0);
            nama.setText(cursor.getString(0).toString());
            cirikhas.setText(cursor.getString(1).toString());
            hobbi.setText(cursor.getString(2).toString());
            jenis.setText(cursor.getString(3).toString());
            lebihkrg.setText(cursor.getString(4).toString());
        }
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = database.getWritableDatabase();
                db.execSQL("update shinchan set nama='" + nama.getText().toString() + "',cirikhas='" + cirikhas.getText().toString() + "',hobi='"
                        + hobbi.getText().toString() + "',jenis='" + jenis.getText().toString() + "',lebihkrg='" + lebihkrg.getText().toString() + "'where nama = '" +
                        getIntent().getStringExtra("nama") + "'");
                Toast.makeText(UpdateShinchan.this, "Data berhasil terupdate", Toast.LENGTH_SHORT).show();
                MainActivity.ma.RefreshList();
                finish();

            }
        });
    }
}